from pathlib import Path
from datetime import datetime
import math

import gpytorch
import numpy as np
import pandas as pd
import torch
from botorch.acquisition.analytic import LogExpectedImprovement
from botorch.fit import fit_gpytorch_mll
from botorch.models import SingleTaskGP
from gpytorch.mlls import ExactMarginalLogLikelihood


# ============================================================
# 1. File settings
# ============================================================

DATA_PATH = Path("data/experiments_noTMG_mixedBO.csv")

OUTPUT_DIR = Path("outputs_noTMG_mixedBO")
OUTPUT_DIR.mkdir(exist_ok=True)

DATA_COLUMNS = [
    "exp_id",
    "base_type",
    "time_min",
    "temp_C",
    "substrate_conc_M",
    "Ni_molpct",
    "Ir_molpct",
    "base_equiv",
    "ABIS_uL",
    "Ni_uL",
    "Ir_uL",
    "base_uL",
    "DMF_uL",
    "yield_percent",
    "productivity_M_per_h",
    "status",
    "note",
]


# ============================================================
# 2. Chemical space
# ============================================================

BASE_TYPES = ["tBu-TMG", "DBU", "Me-TBD"]

# Nominal variable space defined by chemist
TIME_MIN = 10
TIME_MAX = 60

TEMP_MIN = 30
TEMP_MAX = 75

NI_MOLPCT_MIN = 2.5
NI_MOLPCT_MAX = 20.0

IR_MOLPCT_MIN = 0.5
IR_MOLPCT_MAX = 2.0

BASE_EQUIV_MIN = 1.0
BASE_EQUIV_MAX = 2.0

# Fixed substrate concentration for this formal campaign
SUBSTRATE_CONC_M = 0.050


# ============================================================
# 3. Stock solution and volume settings
# ============================================================

TOTAL_VOL_UL = 150.0

# A/B/IS stock is fixed.
# 4'-bromoacetophenone stock concentration in A/B/IS bottle.
SUBSTRATE_STOCK_M = 0.250
ABIS_UL_FIXED = 30.0

# New concentrated stocks for formal BO
NI_STOCK_M = 0.050      # 50 mM
IR_STOCK_M = 0.005      # 5 mM
BASE_STOCK_M = 0.750    # 0.75 M, for each base stock

# Practical liquid-handler / pipetting constraints
MIN_TRANSFER_UL = 10.0
MIN_DMF_UL = 20.0

# Practical rounding
TIME_STEP = 2            # min
TEMP_STEP = 5            # deg C
NI_MOLPCT_STEP = 2.0     # mol%
IR_MOLPCT_STEP = 0.2     # mol%
BASE_EQUIV_STEP = 0.1   # equiv
VOLUME_ROUND_DECIMALS = 0


# ============================================================
# 4. BO settings
# ============================================================

# Number of initial space-filling experiments
NUM_INITIAL_EXPERIMENTS = 12

# Number of BO recommendations to output after initialization
N_RECOMMEND_BO = 3

# Large candidate pool for BO recommendation
CANDIDATE_POOL_SIZE = 15000

# Experimental noise in yield scale
OBS_NOISE_SD_PERCENT = 3.0

# Objective mode:
# "yield"        : maximize yield only
# "time_penalty" : maximize yield - penalty * time
# "productivity" : maximize productivity proxy
OBJECTIVE_MODE = "time_penalty"

# Used only when OBJECTIVE_MODE = "time_penalty"
TIME_PENALTY_PER_MIN = 0.2

RANDOM_SEED = 20260615


# ============================================================
# 5. Helper functions
# ============================================================

def round_to_step(x: float, step: float) -> float:
    return round(round(x / step) * step, 10)


def load_data() -> pd.DataFrame:
    if DATA_PATH.exists():
        df = pd.read_csv(DATA_PATH)
    else:
        df = pd.DataFrame(columns=DATA_COLUMNS)

    for col in DATA_COLUMNS:
        if col not in df.columns:
            df[col] = np.nan

    df = df[DATA_COLUMNS].copy()

    # Safety filter for the no-TMG campaign:
    # ignore any row whose base_type is not included in BASE_TYPES.
    # This prevents old TMG rows from being used accidentally.
    df = df[df["base_type"].astype(str).isin(BASE_TYPES)].copy()

    return df


def substrate_umol() -> float:
    # 1 M = 1 umol/uL
    return SUBSTRATE_STOCK_M * ABIS_UL_FIXED


def calculate_volumes(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    n_sub_umol = substrate_umol()

    out["substrate_conc_M"] = SUBSTRATE_CONC_M
    out["ABIS_uL"] = ABIS_UL_FIXED

    out["Ni_uL"] = (
        n_sub_umol * out["Ni_molpct"].astype(float) / 100.0 / NI_STOCK_M
    )
    out["Ir_uL"] = (
        n_sub_umol * out["Ir_molpct"].astype(float) / 100.0 / IR_STOCK_M
    )
    out["base_uL"] = (
        n_sub_umol * out["base_equiv"].astype(float) / BASE_STOCK_M
    )

    out["DMF_uL"] = (
        TOTAL_VOL_UL
        - out["ABIS_uL"]
        - out["Ni_uL"]
        - out["Ir_uL"]
        - out["base_uL"]
    )

    for col in ["ABIS_uL", "Ni_uL", "Ir_uL", "base_uL", "DMF_uL"]:
        out[col] = out[col].round(VOLUME_ROUND_DECIMALS)

    return out


def is_legal_volume(df: pd.DataFrame) -> pd.Series:
    return (
        (df["Ni_uL"] >= MIN_TRANSFER_UL)
        & (df["Ir_uL"] >= MIN_TRANSFER_UL)
        & (df["base_uL"] >= MIN_TRANSFER_UL)
        & (df["DMF_uL"] >= MIN_DMF_UL)
    )


def get_effective_bounds():
    n_sub_umol = substrate_umol()

    ni_min_by_volume = MIN_TRANSFER_UL * NI_STOCK_M / n_sub_umol * 100.0
    ir_min_by_volume = MIN_TRANSFER_UL * IR_STOCK_M / n_sub_umol * 100.0
    base_min_by_volume = MIN_TRANSFER_UL * BASE_STOCK_M / n_sub_umol

    effective_bounds = {
        "time_min": (TIME_MIN, TIME_MAX),
        "temp_C": (TEMP_MIN, TEMP_MAX),
        "Ni_molpct": (max(NI_MOLPCT_MIN, ni_min_by_volume), NI_MOLPCT_MAX),
        "Ir_molpct": (max(IR_MOLPCT_MIN, ir_min_by_volume), IR_MOLPCT_MAX),
        "base_equiv": (max(BASE_EQUIV_MIN, base_min_by_volume), BASE_EQUIV_MAX),
    }

    return effective_bounds


def generate_continuous_points(n: int, seed: int) -> pd.DataFrame:
    bounds = get_effective_bounds()

    engine = torch.quasirandom.SobolEngine(
        dimension=5,
        scramble=True,
        seed=seed,
    )
    raw = engine.draw(n).numpy()

    rows = []
    for x in raw:
        time_min = bounds["time_min"][0] + x[0] * (
            bounds["time_min"][1] - bounds["time_min"][0]
        )
        temp_C = bounds["temp_C"][0] + x[1] * (
            bounds["temp_C"][1] - bounds["temp_C"][0]
        )
        ni = bounds["Ni_molpct"][0] + x[2] * (
            bounds["Ni_molpct"][1] - bounds["Ni_molpct"][0]
        )
        ir = bounds["Ir_molpct"][0] + x[3] * (
            bounds["Ir_molpct"][1] - bounds["Ir_molpct"][0]
        )
        base_eq = bounds["base_equiv"][0] + x[4] * (
            bounds["base_equiv"][1] - bounds["base_equiv"][0]
        )

        rows.append(
            {
                "time_min": int(round_to_step(time_min, TIME_STEP)),
                "temp_C": int(round_to_step(temp_C, TEMP_STEP)),
                "Ni_molpct": round_to_step(ni, NI_MOLPCT_STEP),
                "Ir_molpct": round_to_step(ir, IR_MOLPCT_STEP),
                "base_equiv": round_to_step(base_eq, BASE_EQUIV_STEP),
            }
        )

    df = pd.DataFrame(rows)

    # Clip after rounding
    for col, (lo, hi) in bounds.items():
        df[col] = df[col].clip(lo, hi)

    return df


def generate_candidate_pool(n_total: int, seed: int) -> pd.DataFrame:
    n_per_base = math.ceil(n_total / len(BASE_TYPES))
    all_parts = []

    for i, base in enumerate(BASE_TYPES):
        cont_df = generate_continuous_points(n_per_base, seed + 101 * i)
        cont_df["base_type"] = base
        all_parts.append(cont_df)

    pool = pd.concat(all_parts, ignore_index=True)

    pool = calculate_volumes(pool)
    pool = pool[is_legal_volume(pool)].copy()

    pool = pool.drop_duplicates(
        subset=[
            "base_type",
            "time_min",
            "temp_C",
            "Ni_molpct",
            "Ir_molpct",
            "base_equiv",
        ]
    ).reset_index(drop=True)

    return pool


def point_key(row) -> tuple:
    return (
        str(row["base_type"]),
        round(float(row["time_min"]), 6),
        round(float(row["temp_C"]), 6),
        round(float(row["Ni_molpct"]), 6),
        round(float(row["Ir_molpct"]), 6),
        round(float(row["base_equiv"]), 6),
    )


def remove_existing_points(candidate_df: pd.DataFrame, data_df: pd.DataFrame) -> pd.DataFrame:
    if len(data_df) == 0:
        return candidate_df.copy()

    existing_df = data_df[
        data_df["status"].astype(str).str.lower().isin(["valid", "pending"])
    ].copy()

    if len(existing_df) == 0:
        return candidate_df.copy()

    existing_keys = set(point_key(row) for _, row in existing_df.iterrows())

    keep = []
    for _, row in candidate_df.iterrows():
        keep.append(point_key(row) not in existing_keys)

    return candidate_df[keep].copy()


def compute_productivity(yield_percent, time_min, substrate_conc_M=SUBSTRATE_CONC_M):
    # M/h proxy:
    # C_product = C_substrate * yield_fraction
    # productivity = C_product / time_h
    yield_fraction = yield_percent / 100.0
    time_h = time_min / 60.0
    return substrate_conc_M * yield_fraction / time_h


def add_objectives(valid_df: pd.DataFrame) -> pd.DataFrame:
    out = valid_df.copy()

    out["yield_percent"] = pd.to_numeric(out["yield_percent"], errors="coerce")
    out["time_min"] = pd.to_numeric(out["time_min"], errors="coerce")

    out["productivity_M_per_h"] = compute_productivity(
        out["yield_percent"],
        out["time_min"],
        SUBSTRATE_CONC_M,
    )

    if OBJECTIVE_MODE == "yield":
        out["objective_score"] = out["yield_percent"]

    elif OBJECTIVE_MODE == "time_penalty":
        out["objective_score"] = (
            out["yield_percent"] - TIME_PENALTY_PER_MIN * out["time_min"]
        )

    elif OBJECTIVE_MODE == "productivity":
        # Multiply by 1000 only to put values on a convenient numerical scale.
        out["objective_score"] = out["productivity_M_per_h"] * 1000.0

    else:
        raise ValueError(
            "OBJECTIVE_MODE must be one of: 'yield', 'time_penalty', 'productivity'"
        )

    return out


def get_valid_df(df: pd.DataFrame) -> pd.DataFrame:
    valid_df = df[
        (df["status"].astype(str).str.lower() == "valid")
        & (pd.to_numeric(df["yield_percent"], errors="coerce").notna())
    ].copy()

    if len(valid_df) == 0:
        return valid_df

    valid_df = calculate_volumes(valid_df)
    valid_df = add_objectives(valid_df)

    return valid_df


def encode_features(df: pd.DataFrame) -> torch.Tensor:
    bounds = get_effective_bounds()

    cont_cols = ["time_min", "temp_C", "Ni_molpct", "Ir_molpct", "base_equiv"]

    cont_values = []
    for col in cont_cols:
        lo, hi = bounds[col]
        normalized = (pd.to_numeric(df[col], errors="coerce") - lo) / (hi - lo)
        cont_values.append(normalized.to_numpy(dtype=float).reshape(-1, 1))

    cont_matrix = np.hstack(cont_values)

    base_matrix = np.zeros((len(df), len(BASE_TYPES)), dtype=float)
    for i, base in enumerate(df["base_type"].astype(str).tolist()):
        if base not in BASE_TYPES:
            raise ValueError(f"Unknown base_type: {base}. Allowed: {BASE_TYPES}")
        base_matrix[i, BASE_TYPES.index(base)] = 1.0

    x = np.hstack([cont_matrix, base_matrix])
    return torch.tensor(x, dtype=torch.double)


def assign_exp_ids(recommend_df: pd.DataFrame, data_df: pd.DataFrame) -> pd.DataFrame:
    out = recommend_df.copy()

    if len(data_df) == 0 or pd.to_numeric(data_df["exp_id"], errors="coerce").dropna().empty:
        start_id = 1
    else:
        start_id = int(pd.to_numeric(data_df["exp_id"], errors="coerce").max()) + 1

    out.insert(0, "exp_id", range(start_id, start_id + len(out)))
    return out


def format_recommendation_output(df: pd.DataFrame, note: str) -> pd.DataFrame:
    out = df.copy()

    out["substrate_conc_M"] = SUBSTRATE_CONC_M
    out["yield_percent"] = ""
    out["productivity_M_per_h"] = ""
    out["status"] = "pending"
    out["note"] = note

    for col in DATA_COLUMNS:
        if col not in out.columns:
            out[col] = ""

    return out[DATA_COLUMNS + [c for c in out.columns if c not in DATA_COLUMNS]]


def save_outputs(recommend_df: pd.DataFrame, ranked_df: pd.DataFrame | None, prefix: str):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    latest_rec_path = OUTPUT_DIR / f"latest_{prefix}_recommendations.csv"
    timed_rec_path = OUTPUT_DIR / f"{timestamp}_{prefix}_recommendations.csv"

    recommend_df.to_csv(latest_rec_path, index=False, encoding="utf-8-sig")
    recommend_df.to_csv(timed_rec_path, index=False, encoding="utf-8-sig")

    print("\nRecommended experiments:")
    print(recommend_df)

    print(f"\nSaved latest recommendations to: {latest_rec_path}")
    print(f"Saved timestamped recommendations to: {timed_rec_path}")

    if ranked_df is not None:
        latest_ranked_path = OUTPUT_DIR / f"latest_{prefix}_all_candidate_scores.csv"
        timed_ranked_path = OUTPUT_DIR / f"{timestamp}_{prefix}_all_candidate_scores.csv"

        ranked_df.to_csv(latest_ranked_path, index=False, encoding="utf-8-sig")
        ranked_df.to_csv(timed_ranked_path, index=False, encoding="utf-8-sig")

        print(f"Saved latest candidate scores to: {latest_ranked_path}")
        print(f"Saved timestamped candidate scores to: {timed_ranked_path}")


def pareto_front(df: pd.DataFrame) -> pd.DataFrame:
    if len(df) == 0:
        return df.copy()

    work = df.copy()
    y = work["yield_percent"].to_numpy(dtype=float)
    p = work["productivity_M_per_h"].to_numpy(dtype=float)

    is_pareto = np.ones(len(work), dtype=bool)

    for i in range(len(work)):
        for j in range(len(work)):
            if i == j:
                continue
            # j dominates i if j is >= in both and > in at least one
            if (y[j] >= y[i]) and (p[j] >= p[i]) and ((y[j] > y[i]) or (p[j] > p[i])):
                is_pareto[i] = False
                break

    out = work[is_pareto].copy()
    out = out.sort_values(["yield_percent", "productivity_M_per_h"], ascending=False)
    return out


# ============================================================
# 6. Initialization design
# ============================================================

def recommend_initialization(df: pd.DataFrame):
    existing_df = df[
        df["status"].astype(str).str.lower().isin(["valid", "pending"])
    ].copy()

    n_existing = len(existing_df)
    n_needed = max(0, NUM_INITIAL_EXPERIMENTS - n_existing)

    if n_needed == 0:
        print(
            f"\nInitialization already has {n_existing} valid/pending experiments. "
            "No initialization recommendations needed."
        )
        return

    print(f"\nGenerating {n_needed} initialization experiments...")

    pool = generate_candidate_pool(20000, RANDOM_SEED)
    pool = remove_existing_points(pool, df)

    if len(pool) < n_needed:
        raise ValueError("Not enough legal initialization candidates. Relax constraints.")

    # Balanced selection over base types
    existing_counts = {
        base: int((existing_df["base_type"].astype(str) == base).sum())
        for base in BASE_TYPES
    }

    target_per_base = math.ceil(NUM_INITIAL_EXPERIMENTS / len(BASE_TYPES))

    selected_parts = []

    for base in BASE_TYPES:
        need_base = max(0, target_per_base - existing_counts[base])
        if need_base == 0:
            continue

        base_pool = pool[pool["base_type"] == base].copy()
        selected_parts.append(base_pool.head(need_base))

    selected = pd.concat(selected_parts, ignore_index=True)

    if len(selected) > n_needed:
        selected = selected.head(n_needed).copy()

    if len(selected) < n_needed:
        selected_keys = set(point_key(row) for _, row in selected.iterrows())
        rest = pool[
            [point_key(row) not in selected_keys for _, row in pool.iterrows()]
        ].copy()
        selected = pd.concat(
            [selected, rest.head(n_needed - len(selected))],
            ignore_index=True,
        )

    selected = assign_exp_ids(selected, df)
    recommend_df = format_recommendation_output(
        selected,
        note="noTMG_init_sobol_balanced",
    )

    save_outputs(recommend_df, ranked_df=None, prefix="noTMG_initialization")


# ============================================================
# 7. BO recommendation
# ============================================================

def recommend_bo(df: pd.DataFrame, valid_df: pd.DataFrame):
    print("\nValid experiments used for BO:")
    print(
        valid_df[
            [
                "exp_id",
                "base_type",
                "time_min",
                "temp_C",
                "Ni_molpct",
                "Ir_molpct",
                "base_equiv",
                "yield_percent",
                "productivity_M_per_h",
                "objective_score",
            ]
        ]
    )

    best_yield = valid_df.loc[valid_df["yield_percent"].idxmax()]
    best_prod = valid_df.loc[valid_df["productivity_M_per_h"].idxmax()]
    best_obj = valid_df.loc[valid_df["objective_score"].idxmax()]

    print("\nCurrent best by yield:")
    print(best_yield[["exp_id", "base_type", "time_min", "temp_C", "Ni_molpct", "Ir_molpct", "base_equiv", "yield_percent"]])

    print("\nCurrent best by productivity:")
    print(best_prod[["exp_id", "base_type", "time_min", "temp_C", "Ni_molpct", "Ir_molpct", "base_equiv", "productivity_M_per_h"]])

    print("\nCurrent best by objective score:")
    print(best_obj[["exp_id", "base_type", "time_min", "temp_C", "Ni_molpct", "Ir_molpct", "base_equiv", "objective_score"]])

    pareto_df = pareto_front(valid_df)
    pareto_path = OUTPUT_DIR / "latest_noTMG_pareto_front.csv"
    pareto_df.to_csv(pareto_path, index=False, encoding="utf-8-sig")
    print(f"\nSaved Pareto front to: {pareto_path}")

    # Prepare training data
    X = encode_features(valid_df)

    Y_raw = torch.tensor(
        valid_df[["objective_score"]].to_numpy(dtype=float),
        dtype=torch.double,
    )

    y_mean = Y_raw.mean()
    y_std = Y_raw.std()

    if y_std < 1e-8:
        y_std = torch.tensor(1.0, dtype=torch.double)

    Y = (Y_raw - y_mean) / y_std

    # Observation noise, scaled into standardized objective scale
    Yvar = torch.full_like(Y, (OBS_NOISE_SD_PERCENT / y_std) ** 2)

    model = SingleTaskGP(X, Y, train_Yvar=Yvar)
    mll = ExactMarginalLogLikelihood(model.likelihood, model)

    fit_gpytorch_mll(mll)

    model.eval()
    model.likelihood.eval()

    # Candidate pool
    candidate_df = generate_candidate_pool(CANDIDATE_POOL_SIZE, RANDOM_SEED + 999)
    candidate_df = remove_existing_points(candidate_df, df)

    if len(candidate_df) == 0:
        raise ValueError("No legal new candidate points remain.")

    candidate_X = encode_features(candidate_df)

    best_f = Y.max()
    acq_func = LogExpectedImprovement(model=model, best_f=best_f)

    with torch.no_grad(), gpytorch.settings.fast_pred_var():
        log_ei = acq_func(candidate_X.unsqueeze(1))
        posterior = model.posterior(candidate_X)

        pred_obj_std = posterior.mean.squeeze(-1)
        pred_std_std = posterior.variance.sqrt().squeeze(-1)

    candidate_df["predicted_objective_score"] = (
        pred_obj_std * y_std + y_mean
    ).detach().numpy()

    candidate_df["uncertainty_std"] = (
        pred_std_std * y_std
    ).detach().numpy()

    candidate_df["log_ei_score"] = log_ei.detach().numpy()

    if OBJECTIVE_MODE == "yield":
        candidate_df["implied_predicted_yield_percent"] = candidate_df["predicted_objective_score"]

    elif OBJECTIVE_MODE == "time_penalty":
        candidate_df["implied_predicted_yield_percent"] = (
            candidate_df["predicted_objective_score"]
            + TIME_PENALTY_PER_MIN * candidate_df["time_min"]
        )

    else:
        candidate_df["implied_predicted_yield_percent"] = ""

    ranked = candidate_df.sort_values("log_ei_score", ascending=False).copy()
    recommend = ranked.head(N_RECOMMEND_BO).copy()

    recommend = assign_exp_ids(recommend, df)
    recommend_df = format_recommendation_output(
        recommend,
        note=f"noTMG_BO_LogEI_{OBJECTIVE_MODE}",
    )

    save_outputs(recommend_df, ranked_df=ranked, prefix="noTMG_BO")


# ============================================================
# 8. Main
# ============================================================

def main():
    print("\n=== no-TMG mixed-variable BO recommendation ===")

    effective_bounds = get_effective_bounds()

    print("\nNominal variable space:")
    print(f"base_type: {BASE_TYPES}")
    print(f"time_min: {TIME_MIN} - {TIME_MAX} min")
    print(f"temp_C: {TEMP_MIN} - {TEMP_MAX} C")
    print(f"Ni_molpct: {NI_MOLPCT_MIN} - {NI_MOLPCT_MAX} mol%")
    print(f"Ir_molpct: {IR_MOLPCT_MIN} - {IR_MOLPCT_MAX} mol%")
    print(f"base_equiv: {BASE_EQUIV_MIN} - {BASE_EQUIV_MAX} equiv")

    print("\nEffective variable space after minimum-transfer filtering:")
    for key, value in effective_bounds.items():
        print(f"{key}: {value[0]:.3f} - {value[1]:.3f}")

    print("\nStock solution settings:")
    print(f"ABIS_uL fixed: {ABIS_UL_FIXED} uL")
    print(f"Ni stock: {NI_STOCK_M * 1000:.1f} mM")
    print(f"Ir stock: {IR_STOCK_M * 1000:.1f} mM")
    print(f"Base stock: {BASE_STOCK_M:.2f} M")
    print(f"Minimum transfer volume: {MIN_TRANSFER_UL} uL")
    print(f"Minimum DMF volume: {MIN_DMF_UL} uL")

    df = load_data()
    valid_df = get_valid_df(df)

    print(f"\nTotal rows in data file: {len(df)}")
    print(f"Valid rows with yield: {len(valid_df)}")

    # No enough initial data: generate initialization design
    if len(valid_df) < NUM_INITIAL_EXPERIMENTS:
        recommend_initialization(df)
        return

    # Enough data: run BO refinement
    recommend_bo(df, valid_df)


if __name__ == "__main__":
    main()